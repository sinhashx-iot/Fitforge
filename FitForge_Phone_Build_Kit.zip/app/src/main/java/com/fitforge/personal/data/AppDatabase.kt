package com.fitforge.personal.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "fitness")
data class FitnessDay(
    @PrimaryKey val date: String,
    val steps: Int = 0,
    val workoutMinutes: Int = 0,
    val waterMl: Int = 0,
    val calories: Int = 0,
    val weightKg: Double = 0.0
)

@Entity(tableName = "finance")
data class FinanceEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: String,
    val title: String,
    val amount: Double,
    val type: String,
    val category: String
)

@Dao
interface FitnessDao {
    @Query("SELECT * FROM fitness WHERE date = :date LIMIT 1")
    fun observe(date: String): Flow<FitnessDay?>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun save(day: FitnessDay)
}

@Dao
interface FinanceDao {
    @Query("SELECT * FROM finance ORDER BY id DESC")
    fun observeAll(): Flow<List<FinanceEntry>>
    @Insert suspend fun insert(entry: FinanceEntry)
    @Delete suspend fun delete(entry: FinanceEntry)
}

@Database(entities = [FitnessDay::class, FinanceEntry::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun fitnessDao(): FitnessDao
    abstract fun financeDao(): FinanceDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun get(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "fitforge.db"
                ).build().also { INSTANCE = it }
            }
    }
}
