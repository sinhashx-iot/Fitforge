# FitForge

Personal, offline-first fitness + finance Android app.

## Phone-only APK build

This repository includes a GitHub Actions workflow. You do NOT need Android Studio.

1. Create a GitHub repository.
2. Upload `FitForge_Android_Project.zip` to the repository root.
3. Upload `.github/workflows/build-apk.yml` into `.github/workflows/`.
4. Open GitHub → Actions → **Build FitForge APK**.
5. Tap **Run workflow**.
6. Wait for the green check.
7. Open the workflow run and download the **FitForge-debug-apk** artifact.
8. Extract the downloaded ZIP and install `app-debug.apk` on your phone.

The build uses Java 17 and Gradle 8.10.2 on a GitHub-hosted Linux runner.

## Features

- No account/signup/login
- Local Room database
- Fitness dashboard
- Steps, workout minutes, water intake
- Daily finance income/expense tracking
- Balance and statistics
- Cinematic superhero-style intro animation
- Android 8.0+ (API 26+) support

The intro is original cinematic styling and does not use Marvel logos, characters, artwork, or music.
